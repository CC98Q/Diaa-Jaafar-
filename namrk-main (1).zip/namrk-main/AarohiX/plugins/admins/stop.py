from pyrogram import filters 
from pyrogram.types import Message 
from strings.filters import command 
from AarohiX import app 
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton 
from config import Muntazer 
from pyrogram.errors import ChatAdminRequired, UserNotParticipant, ChatWriteForbidden 
from AarohiX.core.call import Dil
from AarohiX.utils.database import set_loop 
from AarohiX.utils.decorators import AdminRightsCheck 
from AarohiX.utils.inline import close_markup 
 
@app.on_message(filters.incoming & filters.private, group=-1) 
async def must_join_channel(cli, msg: Message): 
    if not Muntazer: 
        return 
    try: 
        try: 
            await cli.get_chat_member(Muntazer, msg.from_user.id) 
        except UserNotParticipant: 
            if Muntazer.isalpha(): 
                link = "https://t.me/" + Muntazer 
            else: 
                chat_info = await cli.get_chat(Muntazer) 
                link = chat_info.invite_link 
            try: 
                await msg.reply( 
                    f"~︙عزيزي {msg.from_user.mention} \n~︙عليك الأشتراك في قناة البوت \n~︙قناة البوت : @{Muntazer}.", 
                    disable_web_page_preview=True, 
                    reply_markup=InlineKeyboardMarkup([ 
                        [InlineKeyboardButton("< Source Plus >", url=link)] 
                    ]) 
                ) 
                await msg.stop_propagation() 
            except ChatWriteForbidden: 
                pass 
    except ChatAdminRequired: 
        print(f"I'm not admin in the MUST_JOIN chat {Muntazer}!") 
 
# الكود لإيقاف الموسيقى 
@app.on_message(command(["ايقاف", "اوكف", "كافي", "انهاء"]) ) 
@AdminRightsCheck 
async def stop_music(cli, message: Message, _, chat_id): 
    if not len(message.command) == 1: 
        return 
    # التحقق من الاشتراك في القناة 
    await must_join_channel(cli, message) 
    await Dil.stop_stream(chat_id) 
    await set_loop(chat_id, 0) 
    await message.reply_text( 
        _["admin_5"].format(message.from_user.mention), reply_markup=close_markup(_) 
    )
